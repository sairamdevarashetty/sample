"""
One-time script to create Amber's Gemini File Search Store and upload KB documents.

Run once:
    uv run create_kb_store.py

Copy the printed store ID into bot.py (FILE_SEARCH_STORE_NAME).
"""

import os
import pathlib
from dotenv import load_dotenv
from google import genai

load_dotenv(override=True)

KB_DIR = pathlib.Path(__file__).parent / "kb"
STORE_DISPLAY_NAME = "amber-kb"

client = genai.Client(api_key=os.getenv("GEMINI_API_KEY"))


def get_or_create_store():
    # Check if store already exists
    for store in client.file_search_stores.list():
        if store.display_name == STORE_DISPLAY_NAME:
            print(f"Found existing store: {store.name}")
            return store

    store = client.file_search_stores.create(
        config={"display_name": STORE_DISPLAY_NAME}
    )
    print(f"Created new store: {store.name}")
    return store


def upload_files(store):
    files = list(KB_DIR.iterdir())
    if not files:
        print("No files found in kb/")
        return

    for file_path in files:
        if file_path.suffix in {".xlsx", ".pdf", ".txt", ".csv", ".docx"}:
            print(f"Uploading {file_path.name}...")
            client.file_search_stores.upload_to_file_search_store(
                file_search_store_name=store.name,
                file=file_path,
            )
            print(f"  Done: {file_path.name}")
        else:
            print(f"  Skipping unsupported file: {file_path.name}")



if __name__ == "__main__":
    store = get_or_create_store()
    upload_files(store)
    print(f"\n✓ Store ready. Add this to bot.py:\n  FILE_SEARCH_STORE_NAME = \"{store.name}\"")
