#
# Copyright (c) 2025, Daily
#
# SPDX-License-Identifier: BSD 2-Clause License
#

import asyncio
import json
import os
import pathlib
import sys

import pandas as pd
from dotenv import load_dotenv
from loguru import logger
from pipecat.audio.vad.silero import SileroVADAnalyzer
from pipecat.frames.frames import EndFrame, TTSSpeakFrame
from pipecat.pipeline.pipeline import Pipeline
from pipecat.pipeline.runner import PipelineRunner
from pipecat.pipeline.task import PipelineParams, PipelineTask
from pipecat.processors.aggregators.llm_context import LLMContext
from pipecat.processors.aggregators.llm_response_universal import (
    LLMContextAggregatorPair,
    LLMUserAggregatorParams,
)
from pipecat.runner.types import RunnerArguments
from pipecat.runner.utils import parse_telephony_websocket
from pipecat.serializers.exotel import ExotelFrameSerializer
from google.genai import types
from pipecat.services.google.llm import GoogleLLMService
from pipecat.services.sarvam.stt import SarvamSTTService
from pipecat_murf_tts import MurfTTSService
from pipecat.transports.base_transport import BaseTransport
from pipecat.transports.websocket.fastapi import (
    FastAPIWebsocketParams,
    FastAPIWebsocketTransport,
)

load_dotenv(override=True)

# ── Shared resources (all files live alongside bot.py) ───────────────────────
_BOT_DIR = pathlib.Path(__file__).parent
sys.path.insert(0, str(_BOT_DIR))
from amber_prompt_poc import messages as _base_messages  # noqa: E402

FILE_SEARCH_STORE_NAME = os.getenv("AMBER_KB_STORE_NAME", "")

# ── Inventory loaded once at startup (never read mid-call) ────────────────────
_INVENTORY_PATH = _BOT_DIR / "amber_property_inventory.xlsx"
_inventory_df = pd.read_excel(_INVENTORY_PATH, sheet_name="Property Inventory", header=1)
_lookup_df = pd.read_excel(_INVENTORY_PATH, sheet_name="Pre-Load Lookup", header=1)
logger.info(f"Inventory loaded: {len(_inventory_df)} properties, {len(_lookup_df)} university mappings")


def _lookup_properties(university: str, city: str, room_type: str, budget: float) -> str:
    """Filter inventory in memory and return a formatted string for the LLM."""
    prop_ids = []
    commute_note = ""

    # Step 1: match university via Pre-Load Lookup
    if university:
        match = _lookup_df[
            _lookup_df["University Keyword"].str.lower().str.contains(
                university.lower(), na=False
            )
        ]
        if not match.empty:
            row = match.iloc[0]
            prop_ids = [row.get("Property 1 ID"), row.get("Property 2 ID"), row.get("Property 3 ID")]
            prop_ids = [p for p in prop_ids if pd.notna(p)]
            commute_note = row.get("Aria Commute Note", "")

    # Step 2: start from matched IDs or full inventory
    if prop_ids:
        df = _inventory_df[_inventory_df["Property ID"].isin(prop_ids)].copy()
    else:
        df = _inventory_df.copy()

    # Step 3: filter by city
    if city:
        df = df[df["City"].str.lower().str.contains(city.lower(), na=False)]

    # Step 4: filter by room type
    if room_type:
        df = df[df["Room Types Available"].str.lower().str.contains(room_type.lower(), na=False)]

    # Step 5: filter by budget
    if budget:
        df = df[df["Price From (weekly)"] <= float(budget)]

    if df.empty:
        return "No properties found matching the criteria. Try broadening the budget or room type."

    # Return top 2 as per Stage 10
    lines = []
    if commute_note:
        lines.append(f"Commute note: {commute_note}\n")
    for i, p in enumerate(df.head(2).to_dict("records"), 1):
        lines.append(f"Option {i}: {p['Property Name']}")
        lines.append(f"  Price: {p['Price Spoken (Aria script)']}")
        lines.append(f"  Room types: {p['Room Types Available']}")
        lines.append(f"  Bills included: {p['Bills Included']}")
        lines.append(f"  No Visa No Pay: {p['No Visa No Pay']}")
        lines.append(f"  Instalments: {p['Pay in Instalments']}")
        lines.append(f"  Guarantor: {p['Guarantor Accepted']}")
        lines.append(f"  Amenities: {p['Key Amenities']}")
        lines.append(f"  Distance to uni: {p['Distance to Uni (mins by transit)']}")
        lines.append(f"  Active offers: {p['Active Offers']}")
        lines.append(f"  Tips: {p['Notes / Aria Tips']}")
        lines.append("")
    return "\n".join(lines)


# ── Transfer state ────────────────────────────────────────────────────────────
_TRANSFER_STATE_FILE = pathlib.Path(__file__).parent / "transfer_state.json"
_transfer_states: dict = {}


def _save_transfer_state(call_id: str, should_transfer: bool):
    _transfer_states[call_id] = should_transfer
    try:
        with open(_TRANSFER_STATE_FILE, "w") as f:
            json.dump(_transfer_states, f)
    except Exception as e:
        logger.error(f"Failed to save transfer state: {e}")


def _get_transfer_state(call_id: str) -> bool:
    if call_id in _transfer_states:
        return _transfer_states[call_id]
    try:
        with open(_TRANSFER_STATE_FILE) as f:
            data = json.load(f)
            return data.get(call_id, False)
    except (FileNotFoundError, json.JSONDecodeError):
        return False


# ── Tool declarations ─────────────────────────────────────────────────────────
_get_properties_declaration = types.FunctionDeclaration(
    name="get_properties",
    description="Look up matching properties from inventory by university, city, room type, and weekly budget.",
    parameters={
        "type": "object",
        "properties": {
            "university": {"type": "string", "description": "University name the student is attending"},
            "city":       {"type": "string", "description": "City where accommodation is needed"},
            "room_type":  {"type": "string", "description": "Room type: ensuite or studio"},
            "budget":     {"type": "number", "description": "Maximum weekly budget in GBP"},
        },
        "required": ["university", "city", "room_type", "budget"],
    },
)

_transfer_to_agent_declaration = types.FunctionDeclaration(
    name="transfer_to_agent",
    description="Transfer the student to a human specialist. Always say your transfer line out loud first.",
    parameters={"type": "object", "properties": {}, "required": []},
)

_end_call_declaration = types.FunctionDeclaration(
    name="end_call",
    description="End the call after a proper goodbye.",
    parameters={"type": "object", "properties": {}, "required": []},
)


def _build_greeting(name: str) -> str:
    return (
        f"Hi, am I speaking with {name}? "
        "This is Aria calling from Amber, a private student accommodation platform."
    )


async def run_bot(transport: BaseTransport, handle_sigint: bool, call_id: str = "", call_sid: str = "", app_state=None):
    # Resolve customer name stored by /start endpoint
    # Prefer the directly-stored name (call_sid from WS is always empty, so dict key lookup fails)
    customer_name = getattr(app_state, "current_customer_name", None) or \
        (getattr(app_state, "call_answered_events", {}) or {}).get(f"{call_sid}_name", "there")
    greeting_text = _build_greeting(customer_name)
    llm = GoogleLLMService(
        api_key=os.getenv("GEMINI_API_KEY"),
        model="gemini-2.5-flash",
        tools=[
            types.Tool(function_declarations=[
                _get_properties_declaration,
                _transfer_to_agent_declaration,
                _end_call_declaration,
            ]),
        ],
    )

    stt = SarvamSTTService(api_key=os.getenv("SARVAM_API_KEY"), model="saarika:v2.5")

    tts = MurfTTSService(
        api_key=os.getenv("MURF_API_KEY"),
        params=MurfTTSService.InputParams(
            voice_id="Ronnie",
            style="Conversational",
            model="FALCON",
            multi_native_locale="en-IN",
            sample_rate=8000,
            format="PCM",
        ),
    )

    # Shallow copy so each call gets its own list — never mutate the shared _base_messages
    # Replace hardcoded "Rishab" in prompt with actual customer name, then seed greeting
    messages = [
        {**m, "content": m["content"].replace("Rishab", customer_name)} if m["role"] == "system" else m
        for m in _base_messages
    ] + [{"role": "assistant", "content": greeting_text}]

    context = LLMContext(messages)
    user_aggregator, assistant_aggregator = LLMContextAggregatorPair(
        context,
        user_params=LLMUserAggregatorParams(
            vad_analyzer=SileroVADAnalyzer(),
        ),
    )

    pipeline = Pipeline(
        [
            transport.input(),
            stt,
            user_aggregator,
            llm,
            tts,
            transport.output(),
            assistant_aggregator,
        ]
    )

    task = PipelineTask(
        pipeline,
        params=PipelineParams(
            audio_in_sample_rate=8000,
            audio_out_sample_rate=8000,
            enable_metrics=True,
            enable_usage_metrics=True,
        ),
    )

    async def handle_get_properties(params):
        args = params.arguments
        logger.info(f"TOOL: get_properties {args}")
        result = _lookup_properties(
            university=args.get("university", ""),
            city=args.get("city", ""),
            room_type=args.get("room_type", ""),
            budget=args.get("budget", 0),
        )
        logger.info(f"get_properties result:\n{result}")
        await params.result_callback(result)

    async def handle_transfer_to_agent(params):
        logger.info(f"TOOL: transfer_to_agent (call_id={call_id})")
        _save_transfer_state(call_id, should_transfer=True)
        async def _disconnect():
            await asyncio.sleep(4.0)
            await task.queue_frame(EndFrame())
        asyncio.create_task(_disconnect())
        await params.result_callback("")

    async def handle_end_call(params):
        logger.info(f"TOOL: end_call (call_id={call_id})")
        async def _disconnect():
            await asyncio.sleep(4.0)
            await task.queue_frame(EndFrame())
        asyncio.create_task(_disconnect())
        await params.result_callback("")

    llm.register_function("get_properties", handle_get_properties)
    llm.register_function("transfer_to_agent", handle_transfer_to_agent)
    llm.register_function("end_call", handle_end_call)

    async def _wait_and_greet():
        ANSWER_MAX_WAIT = 30.0
        event = getattr(app_state, "pending_answer_event", None) if app_state else None
        if event is None:
            logger.warning("No pending_answer_event on app_state — speaking immediately")
        else:
            try:
                await asyncio.wait_for(asyncio.shield(event.wait()), timeout=ANSWER_MAX_WAIT)
                logger.info(f"Human answered — speaking greeting to {customer_name}")
            except asyncio.TimeoutError:
                logger.warning(f"Answer timed out after {ANSWER_MAX_WAIT}s — ending call")
                await task.cancel()
                return
        await task.queue_frame(TTSSpeakFrame(text=greeting_text))

    @transport.event_handler("on_client_connected")
    async def on_client_connected(transport, client):
        logger.info(f"Outbound on_client_connected (call_id={call_id})")
        asyncio.create_task(_wait_and_greet())

    @transport.event_handler("on_client_disconnected")
    async def on_client_disconnected(transport, client):
        await task.cancel()

    runner = PipelineRunner(handle_sigint=handle_sigint)
    await runner.run(task)


async def bot(runner_args: RunnerArguments):
    """Main bot entry point — called by server.py WebSocket handler."""

    transport_type, call_data = await parse_telephony_websocket(runner_args.websocket)
    logger.info(f"Auto-detected transport: {transport_type}")

    serializer = ExotelFrameSerializer(
        stream_sid=call_data["stream_id"],
        call_sid=call_data["call_id"],
    )

    transport = FastAPIWebsocketTransport(
        websocket=runner_args.websocket,
        params=FastAPIWebsocketParams(
            audio_in_enabled=True,
            audio_out_enabled=True,
            add_wav_header=False,
            serializer=serializer,
        ),
    )

    call_id = call_data.get("call_id", "")
    call_sid = call_data.get("call_sid", "")
    body = runner_args.body if isinstance(runner_args.body, dict) else {}
    app_state = body.get("app_state")
    await run_bot(transport, runner_args.handle_sigint, call_id=call_id, call_sid=call_sid, app_state=app_state)