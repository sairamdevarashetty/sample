#
# Copyright (c) 2025, Daily
#
# SPDX-License-Identifier: BSD 2-Clause License
#

"""server.py

Webhook server to handle outbound call requests, initiate calls via Exotel API,
and handle subsequent WebSocket connections for Media Streams.
"""

import os
from contextlib import asynccontextmanager
from pathlib import Path

import aiohttp
import uvicorn
from dotenv import load_dotenv
from loguru import logger
from fastapi import FastAPI, HTTPException, Request, Response, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse

load_dotenv(override=True)


# ----------------- HELPERS ----------------- #


async def make_exotel_call(session: aiohttp.ClientSession, to_number: str, from_number: str, status_callback_url: str = ""):
    """Make an outbound call using Exotel's Connect API."""
    api_key = os.getenv("EXOTEL_API_KEY")
    api_token = os.getenv("EXOTEL_API_TOKEN")
    sid = os.getenv("EXOTEL_SID")

    if not all([api_key, api_token, sid]):
        raise ValueError("Missing Exotel credentials: EXOTEL_API_KEY, EXOTEL_API_TOKEN, EXOTEL_SID")

    # Exotel Connect API endpoint
    subdomain = os.getenv("EXOTEL_SUBDOMAIN", "api.exotel.com")
    url = f"https://{subdomain}/v1/Accounts/{sid}/Calls/connect"

    # Use form data for Exotel Connect Two Numbers API
    data = {
        "From": from_number,
        "To": to_number,
        "CallerId": from_number,
        "CallType": "trans",
        "StatusCallback": status_callback_url,
        "StatusCallbackEvents[0]": "terminal",
        "StatusCallbackEvents[1]": "answered",
    }

    # Use HTTP Basic Auth
    auth = aiohttp.BasicAuth(api_key, api_token)

    async with session.post(url, data=data, auth=auth) as response:
        if response.status != 200:
            error_text = await response.text()
            raise Exception(f"Exotel API error ({response.status}): {error_text}")

        # Exotel returns XML by default, extract key information
        result_text = await response.text()

        # Extract Sid from XML response for tracking
        call_sid = "unknown"
        if "<Sid>" in result_text:
            start = result_text.find("<Sid>") + 5
            end = result_text.find("</Sid>")
            if end > start:
                call_sid = result_text[start:end]

        return {"status": "call_initiated", "call_sid": call_sid}


# ----------------- API ----------------- #


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.session = aiohttp.ClientSession()
    yield
    await app.state.session.close()


app = FastAPI(lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins for testing
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def index():
    return FileResponse(Path(__file__).parent / "index.html")


@app.post("/start")
async def initiate_outbound_call(request: Request) -> JSONResponse:
    """Handle outbound call request and initiate call via Exotel."""
    print("Received outbound call request")

    try:
        data = await request.json()

        # Validate request data
        if not data.get("dialout_settings"):
            raise HTTPException(
                status_code=400, detail="Missing 'dialout_settings' in the request body"
            )

        if not data["dialout_settings"].get("phone_number"):
            raise HTTPException(
                status_code=400, detail="Missing 'phone_number' in dialout_settings"
            )

        # Extract the phone number and optional customer name
        phone_number = str(data["dialout_settings"]["phone_number"])
        customer_name = str(data["dialout_settings"].get("customer_name", "there"))
        print(f"Processing outbound call to {phone_number} ({customer_name})")

        # Initiate outbound call via Exotel Connect API
        try:
            server_url = os.getenv("SERVER_URL", "").rstrip("/")
            # Reset WS counter BEFORE initiating the call so any incoming WS
            # connections from Exotel are counted from 0 for this call.
            import asyncio
            request.app.state.current_customer_name = customer_name
            request.app.state.pending_answer_event = asyncio.Event()
            request.app.state.call_answered_count = 0
            call_result = await make_exotel_call(
                session=request.app.state.session,
                to_number=phone_number,
                from_number=os.getenv("EXOTEL_PHONE_NUMBER"),
                status_callback_url=f"{server_url}/call-answered",
            )

            call_sid = call_result.get("call_sid", "unknown")

        except Exception as e:
            print(f"Error initiating Exotel call: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to initiate call: {str(e)}")

    except HTTPException:
        raise
    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Server error: {str(e)}")

    return JSONResponse(
        {
            "call_sid": call_sid,
            "status": "call_initiated",
            "phone_number": phone_number,
        }
    )


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """Handle WebSocket connection from Exotel Media Streams."""
    await websocket.accept()

    print(f"WebSocket connection accepted for outbound call")

    try:
        from bot import bot
        from pipecat.runner.types import WebSocketRunnerArguments

        runner_args = WebSocketRunnerArguments(websocket=websocket)
        runner_args.handle_sigint = False
        runner_args.body = {"app_state": app.state}

        await bot(runner_args)

    except Exception as e:
        print(f"Error in WebSocket endpoint: {e}")
        await websocket.close()


# ----------------- Main ----------------- #


@app.post("/call-answered")
async def call_answered(request: Request) -> JSONResponse:
    """Exotel fires once for bot-side (1st) and once for human-side (2nd). Set event on 2nd only."""
    data = await request.form()
    call_sid = data.get("CallSid", "")
    call_status = data.get("Status", "")
    app.state.call_answered_count = getattr(app.state, "call_answered_count", 0) + 1
    count = app.state.call_answered_count
    logger.info(f"/call-answered #{count} CallSid={call_sid} Status={call_status}")
    if count >= 2:
        event = getattr(app.state, "pending_answer_event", None)
        if event:
            event.set()
            logger.info("pending_answer_event set — human has answered")
    return JSONResponse({"status": "ok"})


@app.get("/get_transfer_number")
async def get_transfer_number(CallSid: str = "") -> Response:
    """Called by Exotel Passthru applet after WebSocket closes. Returns 200 to connect to human, 404 to hangup."""
    from bot import _get_transfer_state
    should_transfer = _get_transfer_state(CallSid)
    logger.info(f"/get_transfer_number CallSid={CallSid} → transfer={should_transfer}")
    if should_transfer:
        return Response(status_code=200)
    return Response(status_code=404)


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=7860)
