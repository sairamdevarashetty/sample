# Voice AI Sash

This repository contains four voice AI bot implementations for handling voice calls and interactions via Exotel integration.

## Prerequisites

Before running any bot, ensure you have:

- **Python 3.8+**
- **uv** - Python package manager (`pip install uv`)
- **ngrok** - For tunneling (`https://ngrok.com/`) - Signed in via Google (kaushal@grambvelsai.online)
- **Exotel Account** - Configured and active
- **.env files** - Copy `.env.example` to `.env` in each folder and fill in your API keys

## Setup Instructions

### 1. Environment Variables

Each folder (sash_clothing, cc, amber, partnr) contains a `.env.example` file.

For each bot:

```bash
cp .env.example .env
# Edit .env and add your API keys:
# - SARVAM_API_KEY
# - GEMINI_API_KEY
# - MURF_API_KEY (for cc)
# - ELEVENLABS_API_KEY (for amber)
# - etc.
```

### 2. ngrok Authentication

Configure ngrok with your auth token (run once):

```bash
ngrok config add-authtoken 3ByoDKWJ08Rx7yjOYaNxxZ2Kydv_4PoUgF9C4rNeb6Dg5JtHc
```

---

## Running the Bots

### Sash Clothing Bot

**Terminal 1 - Start the bot:**

```bash
cd sash_clothing
uv run bot.py --transport exotel --proxy horsy-cristin-unprudently.ngrok-free.dev
```

**Terminal 2 - Start ngrok tunnel:**

```bash
ngrok http --url=horsy-cristin-unprudently.ngrok-free.dev 7860
```

**Contact Number:** `080-47361678`

---

### CC Bot

**Terminal 1 - Start the bot:**

```bash
cd cc
uv run bot.py --transport exotel --proxy horsy-cristin-unprudently.ngrok-free.dev
```

**Terminal 2 - Start ngrok tunnel:**

```bash
ngrok http --url=horsy-cristin-unprudently.ngrok-free.dev 7860
```

**Contact Number:** `080-47361678`

---

### Partnr Bot

**Terminal 1 - Start the bot:**

```bash
cd partnr
uv run bot.py --transport exotel --proxy horsy-cristin-unprudently.ngrok-free.dev
```

**Terminal 2 - Start ngrok tunnel:**

```bash
ngrok http --url=horsy-cristin-unprudently.ngrok-free.dev 7860
```

**Contact Number:** `080-47361678`

---

### Amber Bot

**Voice Configuration:**

- Default `bot.py` uses **ElevenLabs** voice
- To use **Murf voice**: Replace `bot.py` with code from `murf.py`
- To switch back to ElevenLabs: Replace with original `bot.py` code

**Terminal 1 - Start the server:**

```bash
cd amber
uv run server.py
```

**Terminal 2 - Start ngrok tunnel:**

```bash
ngrok http --url=horsy-cristin-unprudently.ngrok-free.dev 7860
```

**Access the Amber Call Initiation Webpage:**

- Via ngrok: `https://horsy-cristin-unprudently.ngrok-free.dev/`
- Via EC2 instance: `http://YOUR_EC2_IP:7860/`

Fill in the student name and phone number, then click "Initiate Call" to start an outbound call.

---

## Bot Descriptions

- **sash_clothing** - Voice AI bot for sash clothing inquiries and support
- **cc** - Voice AI bot for CC operations
- **partnr** - Voice AI inbound calling agent for Partnr operations
- **amber** - Server-based voice AI bot for amber services

---

## Troubleshooting

### ngrok Connection Issues

- Verify ngrok auth token is configured correctly
- Check that the proxy URL is accessible
- Ensure ngrok service is running in terminal 2

### Bot Won't Start

- Verify all required API keys are set in `.env`
- Check that port 7860 is not in use
- Ensure `uv` and Python dependencies are installed (`uv sync`)

### Call Routing Not Working

- Confirm Exotel account is active and configured
- Verify the phone number is correct (080-47361678)
- Check ngrok tunnel is connected (should show "online" status)

---

## Verifying the Bots Are Running

After starting both terminals, verify the process:

### 1. Check ngrok Tunnel
- Open ngrok terminal output
- Should show: `Forwarding: https://horsy-cristin-unprudently.ngrok-free.dev -> http://localhost:7860`
- Status should be "online"

### 2. Check Bot Logs
- Review the bot terminal for any errors
- Should show: Bot initialized and listening for calls
- No error messages or connection failures

### 3. Test the Setup
- Make a test call to the contact number: **080-47361678**
- Bot should answer with greeting
- Verify the bot responds to voice input
- Test transfer to human agent if configured

### 4. Verify Ports
- Ensure port 7860 is in use by the bot:
  ```bash
  netstat -an | findstr 7860
  ```
- Should show port listening

---

## Exotel Configuration

### Setting Up Human Agent Transfer

For calls to be transferred to a human agent, you must:

1. **Set HUMAN_AGENT_NUMBER in .env**
   - Add your agent's phone number in the `.env` file for each bot:
   ```
   HUMAN_AGENT_NUMBER=+your_human_agent_number
   ```

2. **Configure in Exotel App Bazar**
   
   Set up the following applets in sequence:

   **Voicebot Applet:**
   - Select your bot (sash_clothing, cc, partnr, or amber)
   - Enter the WebSocket URL:
     ```
     wss://horsy-cristin-unprudently.ngrok-free.dev/ws
     ```
   - Proceed to next applet

   **Passthru Applet:**
   - Use this URL to fetch transfer information:
     ```
     https://horsy-cristin-unprudently.ngrok-free.dev/get_transfer_number?CallSid={{CallSid}}
     ```
   - Set response action to "Connect"

   **Connect Applet:**
   - Select "Dial phone number(s)"
   - Enter the human agent number from your `.env` file
   - Configure ringing duration and conversation limits as needed
   - Set music on hold preference (optional)

3. **Call Flow**
   - Customer calls → Bot answers and processes request
   - If transfer needed → Passthru fetches agent number from .env
   - Call connects to human agent

---

## Support

For issues or questions, check the logs in each bot's terminal and verify all environment variables are correctly set.
