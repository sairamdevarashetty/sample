#
# Partnr — Inbound Voice Bot
# Agent: Namrita | STT: Sarvam | LLM: Gemini 2.5 Flash | TTS: Murf
#

import asyncio
import json
import os
import pathlib
import random
from datetime import datetime

import pandas as pd
from dotenv import load_dotenv
from loguru import logger
from pipecat.audio.vad.silero import SileroVADAnalyzer
from pipecat.frames.frames import EndFrame, LLMFullResponseStartFrame, LLMFullResponseEndFrame, TextFrame
from pipecat.pipeline.pipeline import Pipeline
from pipecat.pipeline.runner import PipelineRunner
from pipecat.pipeline.task import PipelineParams, PipelineTask
from pipecat.processors.aggregators.llm_context import LLMContext
from pipecat.processors.aggregators.llm_response_universal import (
    LLMContextAggregatorPair,
    LLMUserAggregatorParams,
)
from pipecat.runner.types import RunnerArguments
from pipecat.runner.utils import parse_telephony_websocket
from pipecat.serializers.exotel import ExotelFrameSerializer
from google.genai import types
from pipecat.services.google.llm import GoogleLLMService
from pipecat.services.sarvam.stt import SarvamSTTService
from pipecat_murf_tts import MurfTTSService
from pipecat.transports.base_transport import BaseTransport
from pipecat.transports.websocket.fastapi import (
    FastAPIWebsocketParams,
    FastAPIWebsocketTransport,
)

from partnr_system_prompt import messages as system_messages

load_dotenv(override=True)

# ── Catalogue loaded once at startup ──────────────────────────────────────────
_CATALOGUE_PATH = pathlib.Path(__file__).parent / "Partnr_Product_Catalogue_v2.xlsx"

def _load_catalogue() -> list[dict]:
    """Parse Partnr_Product_Catalogue_v2.xlsx into a flat list of product dicts."""
    df = pd.read_excel(_CATALOGUE_PATH, sheet_name="Product Catalogue", header=0)
    df.columns = ["SKU", "Product ID", "Product Name", "Brand", "Category", "MRP", "Compatible Vehicles"]

    products = []
    for _, row in df.iterrows():
        name = row.get("Product Name")
        if not isinstance(name, str) or not name.strip():
            continue
        price_raw = str(row.get("MRP", "")).replace("₹", "").replace(",", "").strip()
        try:
            price = float(price_raw)
        except ValueError:
            price = None
        products.append({
            "sku": str(row.get("SKU", "")).strip(),
            "product_id": str(row.get("Product ID", "")).strip(),
            "name": name.strip(),
            "brand": str(row.get("Brand", "")).strip(),
            "category": str(row.get("Category", "")).strip(),
            "price": price,
            "price_display": str(row.get("MRP", "")).strip(),
            "compatible_vehicles": str(row.get("Compatible Vehicles", "")).strip(),
            "unit": "",
            "availability": "In Stock",
        })
    return products

_CATALOGUE: list[dict] = _load_catalogue()
logger.info(f"Partnr catalogue loaded: {len(_CATALOGUE)} products")


# ── Number to Hindi converter ─────────────────────────────────────────────────
_HINDI_NUMBERS = {
    "0": "शून्य", "1": "एक", "2": "दो", "3": "तीन", "4": "चार", "5": "पाँच",
    "6": "छह", "7": "सात", "8": "आठ", "9": "नौ", "10": "दस",
    "11": "ग्यारह", "12": "बारह", "13": "तेरह", "14": "चौदह", "15": "पंद्रह",
    "16": "सोलह", "17": "सत्रह", "18": "अठारह", "19": "उन्नीस", "20": "बीस",
    "30": "तीस", "40": "चालीस", "50": "पचास", "60": "साठ", "70": "सत्तर",
    "80": "अस्सी", "90": "नब्बे", "100": "सौ"
}

def _convert_number_to_hindi(text: str) -> str:
    """Convert English digits to Hindi words for proper pronunciation."""
    import re
    def replace_number(match):
        num_str = match.group(0)
        if num_str in _HINDI_NUMBERS:
            return _HINDI_NUMBERS[num_str]
        try:
            num = int(num_str)
            if num <= 100:
                if num < 20:
                    return _HINDI_NUMBERS.get(num_str, num_str)
                elif num < 100:
                    tens = (num // 10) * 10
                    ones = num % 10
                    tens_word = _HINDI_NUMBERS.get(str(tens), str(tens))
                    if ones == 0:
                        return tens_word
                    ones_word = _HINDI_NUMBERS.get(str(ones), str(ones))
                    return f"{tens_word} {ones_word}"
            return num_str
        except:
            return num_str
    return re.sub(r'\d+', replace_number, text)


def _get_all_products() -> str:
    """Return all in-stock products grouped by category."""
    by_category: dict[str, list] = {}
    for p in _CATALOGUE:
        by_category.setdefault(p["category"], []).append(p)

    lines = []
    for cat, items in by_category.items():
        lines.append(f"\n{cat}:")
        for p in items:
            status = f" [{p['availability']}]" if p["availability"] != "In Stock" else ""
            price_str = f"Rs.{int(p['price'])}" if p["price"] else p["price_display"]
            price_str = _convert_number_to_hindi(price_str)
            lines.append(f"  - {p['name']} | {price_str} | {p['unit']}{status}")
    return "\n".join(lines) if lines else "No products available."


def _search_products(query: str) -> str:
    """Search catalogue by name or category (case-insensitive)."""
    q = query.lower().strip()
    matches = [
        p for p in _CATALOGUE
        if q in p["name"].lower() or q in p["category"].lower()
    ]
    if not matches:
        return f"No products found matching '{query}'."
    lines = []
    for p in matches:
        status = f" [{p['availability']}]" if p["availability"] != "In Stock" else ""
        price_str = f"Rs.{int(p['price'])}" if p["price"] else p["price_display"]
        price_str = _convert_number_to_hindi(price_str)
        lines.append(f"{p['name']} | {price_str}{status}")
    return "\n".join(lines)


def _check_compatibility(vehicle_make: str, vehicle_model: str, part_type: str) -> str:
    """Check if a part type is compatible with a vehicle make and model."""
    vehicle_key = f"{vehicle_make.strip().lower()} {vehicle_model.strip().lower()}".strip()
    part_query = part_type.strip().lower()

    compatible_products = []
    for p in _CATALOGUE:
        compatible_vehicles = p.get("compatible_vehicles", "").lower()
        product_name = p["name"].lower()

        if vehicle_key in compatible_vehicles and part_query in product_name:
            status = f" [{p['availability']}]" if p["availability"] != "In Stock" else ""
            price_str = f"Rs.{int(p['price'])}" if p["price"] else p["price_display"]
            compatible_products.append(f"{p['name']} | {price_str}{status}")

    if not compatible_products:
        return f"No compatible parts found for {vehicle_make} {vehicle_model} matching '{part_type}'."
    compatible_products = [_convert_number_to_hindi(p) for p in compatible_products]
    return "\n".join(compatible_products)


# ── Order storage (file-based) ────────────────────────────────────────────────
_ORDERS_FILE = pathlib.Path(__file__).parent / "pending_orders.json"


def _load_orders() -> list:
    try:
        with open(_ORDERS_FILE) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []


def _save_orders(orders: list):
    with open(_ORDERS_FILE, "w") as f:
        json.dump(orders, f, indent=2)


def _confirm_order(order_data: dict) -> str:
    """Validate and save a new order. Returns confirmation message or error."""
    required = ["customer_name", "customer_phone",
                "delivery_address", "payment_method", "items", "total_price"]
    missing = [f for f in required if not order_data.get(f)]
    if missing:
        return f"ERROR: Missing fields: {', '.join(missing)}. Collect from mechanic first."

    payment = str(order_data["payment_method"]).upper()
    if payment not in ("UPI", "COD"):
        return "ERROR: payment_method must be UPI or COD."

    order_id = str(random.randint(1000, 9999))
    phone = str(order_data["customer_phone"])
    if not phone.startswith("+"):
        phone = f"+91{phone}"

    order = {
        "order_id": order_id,
        "customer_name": order_data["customer_name"],
        "customer_phone": phone,
        "delivery_address": order_data["delivery_address"],
        "items": order_data["items"],
        "total_price": order_data["total_price"],
        "quantity": order_data.get("quantity", 1),
        "payment_method": payment,
        "payment_status": "CONFIRMED" if payment == "COD" else "PENDING",
        "delivery_status": "Pending",
        "created_at": datetime.now().isoformat(),
    }
    orders = _load_orders()
    orders.append(order)
    _save_orders(orders)
    logger.info(f"Order {order_id} saved")
    return f"Order confirmed. Order number is {order_id}."


def _get_order_by_id(order_id: str) -> str:
    orders = _load_orders()
    for o in orders:
        if str(o.get("order_id")) == str(order_id):
            return (
                f"Order {o['order_id']}: {o['items']} | "
                f"Status: {o['delivery_status']} | "
                f"Payment: {o['payment_status']} | "
                f"Placed: {o['created_at'][:10]}"
            )
    return f"Order {order_id} not found."


def _get_mechanic_orders(phone: str) -> str:
    orders = _load_orders()
    # Normalize phone number for comparison
    normalized_phone = phone.strip().replace(" ", "").replace("-", "")
    if not normalized_phone.startswith("+"):
        normalized_phone = f"+91{normalized_phone}"

    matches = [o for o in orders if o.get("customer_phone", "").replace(" ", "").replace("-", "") == normalized_phone]
    if not matches:
        return f"No orders found for {phone}."
    lines = [
        f"Order {o['order_id']}: {o['items']} | Rs.{o['total_price']} | {o['delivery_status']}"
        for o in matches
    ]
    return "\n".join(lines)


def _update_order(order_id: str, fields: dict) -> str:
    orders = _load_orders()
    for o in orders:
        if str(o.get("order_id")) == str(order_id):
            if o.get("delivery_status", "").lower() not in ("pending", ""):
                return f"Order {order_id} has already been dispatched and cannot be modified."
            allowed = ["delivery_address", "customer_phone", "customer_email",
                       "customer_name", "items", "total_price", "payment_method"]
            updated = []
            for k, v in fields.items():
                if k in allowed and v:
                    o[k] = v
                    updated.append(k)
            _save_orders(orders)
            return f"Order {order_id} updated: {', '.join(updated)}." if updated else "Nothing to update."
    return f"Order {order_id} not found."


# ── Transfer state ────────────────────────────────────────────────────────────
_TRANSFER_STATE_FILE = pathlib.Path(__file__).parent / "transfer_state.json"
_transfer_states: dict = {}


def _save_transfer_state(call_id: str, should_transfer: bool):
    _transfer_states[call_id] = should_transfer
    try:
        with open(_TRANSFER_STATE_FILE, "w") as f:
            json.dump(_transfer_states, f)
    except Exception as e:
        logger.error(f"Failed to save transfer state: {e}")


def _get_transfer_state(call_id: str) -> bool:
    if call_id in _transfer_states:
        return _transfer_states[call_id]
    try:
        with open(_TRANSFER_STATE_FILE) as f:
            data = json.load(f)
            return data.get(call_id, False)
    except (FileNotFoundError, json.JSONDecodeError):
        return False


# ── Tool declarations ─────────────────────────────────────────────────────────
_tool_declarations = [
    types.FunctionDeclaration(
        name="get_all_products",
        description="Get all available spare parts and lubricants from the Partnr catalogue.",
        parameters={"type": "object", "properties": {}, "required": []},
    ),
    types.FunctionDeclaration(
        name="search_products_by_name",
        description="Search for spare parts by name or category (e.g., 'brake pad', 'oil filter', 'battery').",
        parameters={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Product name or category to search for"},
            },
            "required": ["query"],
        },
    ),
    types.FunctionDeclaration(
        name="check_compatibility",
        description="Check if a spare part is compatible with a specific two-wheeler make and model.",
        parameters={
            "type": "object",
            "properties": {
                "vehicle_make":  {"type": "string", "description": "Vehicle brand (e.g., 'Honda', 'Hero', 'Bajaj')"},
                "vehicle_model": {"type": "string", "description": "Vehicle model (e.g., 'CB Shine', 'Splendor', 'Pulsar')"},
                "part_type":     {"type": "string", "description": "Type of part being searched (e.g., 'brake pad', 'oil filter', 'battery')"},
            },
            "required": ["vehicle_make", "vehicle_model", "part_type"],
        },
    ),
    types.FunctionDeclaration(
        name="confirm_order",
        description="Confirm and save a new order once ALL mechanic details are collected.",
        parameters={
            "type": "object",
            "properties": {
                "customer_name":    {"type": "string", "description": "Mechanic name"},
                "customer_phone":   {"type": "string", "description": "Mechanic phone number"},
                "delivery_address": {"type": "string", "description": "Workshop delivery address"},
                "items":            {"type": "string", "description": "Product name(s) ordered"},
                "total_price":      {"type": "number", "description": "Total price in rupees"},
                "quantity":         {"type": "number", "description": "Quantity ordered"},
                "payment_method":   {"type": "string", "enum": ["UPI", "COD"], "description": "UPI or COD — must be explicitly stated by mechanic"},
            },
            "required": ["customer_name", "customer_phone",
                         "delivery_address", "items", "total_price", "payment_method"],
        },
    ),
    types.FunctionDeclaration(
        name="get_order_by_id",
        description="Look up an existing order by order ID.",
        parameters={
            "type": "object",
            "properties": {
                "order_id": {"type": "string", "description": "Order ID number"},
            },
            "required": ["order_id"],
        },
    ),
    types.FunctionDeclaration(
        name="get_mechanic_orders",
        description="Get all orders for a mechanic by their phone number.",
        parameters={
            "type": "object",
            "properties": {
                "phone": {"type": "string", "description": "Mechanic phone number"},
            },
            "required": ["phone"],
        },
    ),
    types.FunctionDeclaration(
        name="update_customer_order",
        description="Update details of a pending order (address, phone, items, payment method).",
        parameters={
            "type": "object",
            "properties": {
                "order_id":         {"type": "string",  "description": "Order ID to update"},
                "delivery_address": {"type": "string",  "description": "New delivery address (optional)"},
                "customer_phone":   {"type": "string",  "description": "New phone number (optional)"},
                "customer_name":    {"type": "string",  "description": "New name (optional)"},
                "items":            {"type": "string",  "description": "New product description (optional)"},
                "total_price":      {"type": "number",  "description": "New total price (optional)"},
                "payment_method":   {"type": "string",  "enum": ["UPI", "COD"], "description": "New payment method (optional)"},
            },
            "required": ["order_id"],
        },
    ),
    types.FunctionDeclaration(
        name="transfer_to_agent",
        description="Transfer the mechanic to a human support agent. Always say your transfer message out loud first.",
        parameters={"type": "object", "properties": {}, "required": []},
    ),
    types.FunctionDeclaration(
        name="end_call",
        description="End the call after a proper goodbye. Always say farewell out loud first.",
        parameters={"type": "object", "properties": {}, "required": []},
    ),
]


# ── Bot entry point ───────────────────────────────────────────────────────────
async def run_bot(transport: BaseTransport, handle_sigint: bool, call_id: str = ""):
    llm = GoogleLLMService(
        api_key=os.getenv("GEMINI_API_KEY"),
        model="gemini-2.5-flash",
        tools=[types.Tool(function_declarations=_tool_declarations)],
    )

    stt = SarvamSTTService(api_key=os.getenv("SARVAM_API_KEY"), model="saarika:v2.5")

    tts = MurfTTSService(
        api_key=os.getenv("MURF_API_KEY"),
        params=MurfTTSService.InputParams(
            voice_id="Namrita",
            style="Conversational",
            model="FALCON",
            multi_native_locale="hi-IN",
            sample_rate=8000,
            format="PCM",
        ),
    )

    messages = list(system_messages)
    context = LLMContext(messages)
    user_aggregator, assistant_aggregator = LLMContextAggregatorPair(
        context,
        user_params=LLMUserAggregatorParams(
            vad_analyzer=SileroVADAnalyzer(),
        ),
    )

    pipeline = Pipeline(
        [
            transport.input(),
            stt,
            user_aggregator,
            llm,
            tts,
            transport.output(),
            assistant_aggregator,
        ]
    )

    task = PipelineTask(
        pipeline,
        params=PipelineParams(
            audio_in_sample_rate=8000,
            audio_out_sample_rate=8000,
            enable_metrics=True,
            enable_usage_metrics=True,
        ),
    )

    # ── Tool handlers ─────────────────────────────────────────────────────────

    async def handle_get_all_products(params):
        logger.info("TOOL: get_all_products")
        result = _get_all_products()
        await params.result_callback(result)

    async def handle_search_products_by_name(params):
        query = params.arguments.get("query", "")
        logger.info(f"TOOL: search_products_by_name query='{query}'")
        result = _search_products(query)
        await params.result_callback(result)
        # Trigger LLM to respond based on search result
        async def _continue_llm():
            await asyncio.sleep(0.5)
            context.messages.append({"role": "user", "content": ""})
        asyncio.create_task(_continue_llm())

    async def handle_check_compatibility(params):
        vehicle_make = params.arguments.get("vehicle_make", "")
        vehicle_model = params.arguments.get("vehicle_model", "")
        part_type = params.arguments.get("part_type", "")
        logger.info(f"TOOL: check_compatibility make='{vehicle_make}' model='{vehicle_model}' part='{part_type}'")
        result = _check_compatibility(vehicle_make, vehicle_model, part_type)
        await params.result_callback(result)
        # Add small delay to ensure tool result is processed, then LLM continues
        async def _continue_llm():
            await asyncio.sleep(0.5)
            # Add empty turn to trigger LLM to respond based on tool result
            context.messages.append({"role": "user", "content": ""})
        asyncio.create_task(_continue_llm())

    async def handle_confirm_order(params):
        logger.info("TOOL: confirm_order")
        result = _confirm_order(params.arguments)
        await params.result_callback(result)

    async def handle_get_order_by_id(params):
        order_id = params.arguments.get("order_id", "")
        logger.info(f"TOOL: get_order_by_id order_id='{order_id}'")
        result = _get_order_by_id(order_id)
        await params.result_callback(result)

    async def handle_get_mechanic_orders(params):
        phone = params.arguments.get("phone", "")
        logger.info(f"TOOL: get_mechanic_orders phone='{phone}'")
        result = _get_mechanic_orders(phone)
        await params.result_callback(result)

    async def handle_update_customer_order(params):
        order_id = params.arguments.get("order_id", "")
        fields = {k: v for k, v in params.arguments.items() if k != "order_id"}
        logger.info(f"TOOL: update_customer_order order_id='{order_id}'")
        result = _update_order(order_id, fields)
        await params.result_callback(result)

    async def handle_transfer_to_agent(params):
        logger.info(f"TOOL: transfer_to_agent (call_id={call_id})")
        if call_id:
            _save_transfer_state(call_id, should_transfer=True)
        async def _disconnect():
            await asyncio.sleep(4.0)
            await task.queue_frame(EndFrame())
        asyncio.create_task(_disconnect())
        await params.result_callback("")

    async def handle_end_call(params):
        logger.info("TOOL: end_call")
        async def _disconnect():
            await asyncio.sleep(4.0)
            await task.queue_frame(EndFrame())
        asyncio.create_task(_disconnect())
        await params.result_callback("")

    llm.register_function("get_all_products", handle_get_all_products)
    llm.register_function("search_products_by_name", handle_search_products_by_name)
    llm.register_function("check_compatibility", handle_check_compatibility)
    llm.register_function("confirm_order", handle_confirm_order)
    llm.register_function("get_order_by_id", handle_get_order_by_id)
    llm.register_function("get_mechanic_orders", handle_get_mechanic_orders)
    llm.register_function("update_customer_order", handle_update_customer_order)
    llm.register_function("transfer_to_agent", handle_transfer_to_agent)
    llm.register_function("end_call", handle_end_call)

    @transport.event_handler("on_client_connected")
    async def on_client_connected(transport, client):
        logger.info("Client connected - sending greeting immediately")
        greeting = "नमस्ते, मैं Partnr से Priya बोल रही हूँ, मैं आपकी क्या मदद कर सकती हूँ?"
        # Inject greeting into context so LLM knows it was already said
        messages.append({"role": "assistant", "content": greeting})
        # Give transport a moment to be ready, then push greeting to TTS
        await asyncio.sleep(0.5)
        await task.queue_frames([
            LLMFullResponseStartFrame(),
            TextFrame(greeting),
            LLMFullResponseEndFrame(),
        ])
        logger.info("Greeting queued to TTS")

    @transport.event_handler("on_client_disconnected")
    async def on_client_disconnected(transport, client):
        await task.cancel()

    runner = PipelineRunner(handle_sigint=handle_sigint)
    await runner.run(task)


async def bot(runner_args: RunnerArguments):
    """Main bot entry point compatible with Pipecat Cloud."""

    transport_type, call_data = await parse_telephony_websocket(runner_args.websocket)
    logger.info(f"Auto-detected transport: {transport_type}")

    serializer = ExotelFrameSerializer(
        stream_sid=call_data["stream_id"],
        call_sid=call_data["call_id"],
    )

    transport = FastAPIWebsocketTransport(
        websocket=runner_args.websocket,
        params=FastAPIWebsocketParams(
            audio_in_enabled=True,
            audio_out_enabled=True,
            add_wav_header=False,
            serializer=serializer,
        ),
    )

    handle_sigint = runner_args.handle_sigint
    call_id = call_data.get("call_id", "")

    await run_bot(transport, handle_sigint, call_id=call_id)


if __name__ == "__main__":
    from fastapi import Response
    from pipecat.runner import run as _runner_module
    from pipecat.runner.run import main

    _original_create = _runner_module._create_server_app

    def _patched_create(args):
        app = _original_create(args)

        @app.get("/get_transfer_number")
        async def get_transfer_number(CallSid: str = ""):
            should_transfer = _get_transfer_state(CallSid)
            logger.info(f"/get_transfer_number CallSid={CallSid} → transfer={should_transfer}")
            if should_transfer:
                return Response(status_code=200)
            return Response(status_code=404)

        return app

    _runner_module._create_server_app = _patched_create
    main()
